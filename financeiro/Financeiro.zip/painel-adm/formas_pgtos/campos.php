<?php 
$pagina = 'formas_pgtos';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';

 ?>