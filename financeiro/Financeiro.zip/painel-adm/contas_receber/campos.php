<?php 
$pagina = 'contas_receber';
//VARIAVEIS DOS INPUTS
$campo1 = 'descricao';
$campo2 = 'Cliente';
$campo3 = 'Entrada';
$campo4 = 'Documento';
$campo5 = 'plano_conta';
$campo6 = 'data_emissao';
$campo7 = 'Vencimento';
$campo8 = 'Frequencia';
$campo9 = 'Valor';
$campo10 = 'usuario_lanc';
$campo11 = 'usuario_baixa';
$campo12 = 'Caixa';
$campo13 = 'data_recor';
$campo14 = 'juros';
$campo15 = 'Multa';
$campo16 = 'Desconto';
$campo17 = 'SubTotal';
$campo18 = 'data_baixa';
 ?>