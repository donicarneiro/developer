<?php 
$pagina = 'usuarios';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';
$campo2 = 'Email';
$campo3 = 'Senha';
$campo4 = 'Nivel';

 ?>