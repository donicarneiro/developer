<?php 
require_once("../../conexao.php");
require_once("campos.php");
require_once("../rotinas/excluir_por_admin.php");

 ?>