<?php 
$pagina = 'frequencias';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';
$campo2 = 'Dias';


 ?>