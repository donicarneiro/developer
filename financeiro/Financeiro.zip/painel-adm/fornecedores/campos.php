<?php 
$pagina = 'fornecedores';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';
$campo2 = 'Pessoa';
$campo3 = 'Doc';
$campo4 = 'Telefone';
$campo5 = 'Endereco';
$campo6 = 'Ativo';
$campo7 = 'Obs';
$campo8 = 'Banco';
$campo9 = 'Agencia';
$campo10 = 'Conta';
$campo11 = 'Email';
 ?>