<?php 
$pagina = 'contas_despesa';
//VARIAVEIS DOS INPUTS
$campo1 = 'descricao';
$campo2 = 'Valor';
$campo3 = 'Data';
$campo4 = 'usuario';
$campo5 = 'lancamento';
$campo6 = 'documento';
$campo7 = 'plano_conta';
$campo8 = 'Fornecedor';
 ?>