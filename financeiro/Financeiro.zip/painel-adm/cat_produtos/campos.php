<?php 
$pagina = 'cat_produtos';
//VARIAVEIS DOS INPUTS
$campo1 = 'Nome';

 ?>